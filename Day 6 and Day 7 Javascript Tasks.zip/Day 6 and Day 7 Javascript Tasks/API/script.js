function getweather()
{
    const apikey='7f607e4f43b410c9bff4778e2a82d9e6'
    const city =document.getElementById('city').values;
    if(!city){
    alert('please enter a city').value;
    return;
    }

const currentweatherUrl=https='https://api.openweathermap.org/data/2.5/weather?q(city)=$(city)&appid=${apikey}';
const forecastUrl='https://api.openweathermap.org/data/2.5/forecast?q=${city}$appid=${apikey}';

fetch(currentweatherUrl)
    .then(Response=>Response.json())
    .then(data=> {
        displayweather(data);
    })
    .catch(error=> {
        console.error('Error fetching current weather data:',error);
        alert('error fetching curren weather data.Please try again.');

    });

fetch(forecastUrl)
    .then(Response=>Response.json())
    .then(data=> {
        displayHourlyForecast(data.list);
    })
    .catch(error=> {
        console.error('Error fetching hourly weather data:',error);
        alert('error fetching hourly forecast weather data.Please try again.');

    });
}

function displayweather(data) {
    const tempoDivInfo=document.getElementById('temp-div');
    const weatherInfoDiv=document.getElementById('weather-info');
    const weatherIcon=document.getElementById('weather-icon');
    const hourlyforecastDiv=ocument.getElementById('hourly-forecast');

    weatherInfoDiv.innerHTML=' ';
    hourlyforecastDiv.innerHTML=' ';
    tempoDivInfo.innerHTML=' ';
}

function displayweather(data){
    if(data.cod === '404'){
        weatherInfoDiv.innerHTML=`<p>${data.message}</p>`;

    }else{
        const cityName=data.name;
        const temperature=math.round(data.main.temp-273.15);
        const description=data.weather[0].descritpiton;
        const iconcode=data.weather[0].icon;
        const iconUrl='https://openweathermap.org/img/wn/${iconcode}@4.png';

        const temperatureHTML=`<p>${temperature}*C</p>`;
        const weatherHTML=`
        <p>${cityName}</p>
        <p>${description}</p>`;

        InputDeviceInfo.innerHTML=temperatureHTML;
        weatherInfoDiv.innerHTML=weatherHTML;
        weatherIcon.src=iconUrl;
        weatherIcon.alt=description;

        showImage();
    }
    function displayhourlyforecast(hourlydata){
        const hourlyforecastDiv=document.getElementById('hourly-forecast');
        const next24hours=hourlydata.slice(0,8);

        next24hours.forEach(item=>{
            const dateTime=new Date(item.dt*1000);
            const hour=dateTime.getHours();
            const temperature=Math.round(item.main,temp-273.15);
            const iconcode=item.weather[0].icon;
            

            const hourlyItemHtml=`
            <div class="hourly-item">
            <span>${hour}:00</span>
            <span>${temperature}*C</span>
            </div>
            `;
            hourlyforecastDiv.innerHTML+=hourlyItemHtml;

        })
    }

}