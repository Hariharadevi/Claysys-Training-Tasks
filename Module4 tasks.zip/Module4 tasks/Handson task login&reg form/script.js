$(document).ready(function () {
        $("#loginForm").validate({
            rules: {
                loginEmail: {
                    required: true,
                    email: true
                },
                loginPassword: {
                    required: true,
                    minlength: 6
                }
            },
            messages: {
                loginEmail: {
                    required: "Please enter your email",
                    email: "Please enter a valid email"
                },
                loginPassword: {
                    required: "Please enter your password",
                    minlength: "Password must be at least 6 characters long"
                }
            }
        });
        $("#registerForm").validate({
            rules: {
                regName: "required",
                regEmail: {
                    required: true,
                    email: true
                },
                regPassword: {
                    required: true,
                    minlength: 6
                },
                confirmPassword: {
                    required: true,
                    minlength: 6,
                    equalTo: "#regPassword"
                }
            },
            messages: {
                regName: "Please enter your name",
                regEmail: {
                    required: "Please enter your email",
                    email: "Please enter a valid email"
                },
                regPassword: {
                    required: "Please enter a password",
                    minlength: "Password must be at least 6 characters long"
                },
                confirmPassword: {
                    required: "Please confirm your password",
                    equalTo: "Passwords do not match"
                }
            }
        });
    });
